# limited MVE2 validation pack 摘要

## 1. 本轮任务目标

本轮只对上一轮 limited MVE2 初筛中冻结的 9 个候选做 validation pack：成本压力、period slice、top-month sensitivity、rolling validation、小邻域参数复核、benchmark 对比和 trade ledger/signal audit。

## 2. 为什么不是新一轮搜索

本轮不扩 universe，不纳入 excluded tickers，不新增大范围参数搜索，不训练机器学习模型，不启动 formal MVE2。所有输出标记为 `limited_mve2_validation`，所有价格、收益、波动和信号只使用统一 store 的 `adj_close` 和 `volume`。

## 3. 冻结候选清单

| candidate_key                        | bucket_id   | role                       | parameters                                                                      |
|:-------------------------------------|:------------|:---------------------------|:--------------------------------------------------------------------------------|
| NVDA/sma50_200_cooldown_5_confirm_1  | Bucket A    | main_candidate             | {"confirm": 1, "cooldown": 5, "fast": 50, "slow": 200}                          |
| NVDA/ts_mom_63d                      | Bucket A    | main_candidate             | {"window": 63}                                                                  |
| SOXX/sma_20_120                      | Bucket C    | main_candidate             | {"fast": 20, "slow": 120}                                                       |
| UPRO/vol_filter_63d                  | Bucket D    | leveraged_bucket_candidate | {"requires_positive_63d_momentum": true, "threshold_window": 252, "window": 63} |
| SPY/vol_filter_63d                   | Bucket B    | defensive_candidate        | {"requires_positive_63d_momentum": true, "threshold_window": 252, "window": 63} |
| GOOGL/vol_filter_20d                 | Bucket A    | main_candidate             | {"requires_positive_63d_momentum": true, "threshold_window": 252, "window": 20} |
| MSFT/sma_50_200                      | Bucket A    | main_candidate             | {"fast": 50, "slow": 200}                                                       |
| MSTR/sma50_200_cooldown_10_confirm_2 | Bucket F    | observation_only           | {"confirm": 2, "cooldown": 10, "fast": 50, "slow": 200}                         |
| QQQ/trailing_stop_15pct              | Bucket B    | negative_case_observation  | {"stop": 0.15}                                                                  |

## 4. 每个候选 validation 结论

| candidate_key                        | validation_decision               | decision_reason                                                                                    |   CAGR |   max_drawdown |   Calmar |   rolling_pass_rate |
|:-------------------------------------|:----------------------------------|:---------------------------------------------------------------------------------------------------|-------:|---------------:|---------:|--------------------:|
| NVDA/sma50_200_cooldown_5_confirm_1  | conditional_pass                  | Parameter neighborhood includes cliff drop.                                                        | 0.5958 |        -0.3755 |   1.5864 |              1.0000 |
| NVDA/ts_mom_63d                      | conditional_pass                  | Cost stress weakens edge.                                                                          | 0.6011 |        -0.4853 |   1.2388 |              1.0000 |
| SOXX/sma_20_120                      | pass_to_next_validation           | Passes basic benchmark, rolling, cost, and neighborhood checks within limited scope.               | 0.2546 |        -0.2961 |   0.8599 |              0.6321 |
| UPRO/vol_filter_63d                  | conditional_pass_leveraged_bucket | Leveraged ETF bucket must remain separate; any pass is conditional to leveraged-bucket validation. | 0.2106 |        -0.2277 |   0.9249 |              0.8018 |
| SPY/vol_filter_63d                   | conditional_pass                  | Parameter neighborhood includes cliff drop.                                                        | 0.0806 |        -0.0786 |   1.0261 |              1.0000 |
| GOOGL/vol_filter_20d                 | conditional_pass                  | Parameter neighborhood includes cliff drop.                                                        | 0.1674 |        -0.1964 |   0.8527 |              0.8977 |
| MSFT/sma_50_200                      | conditional_pass                  | Mixed rolling or benchmark evidence; needs portfolio/K-line validation.                            | 0.2120 |        -0.2804 |   0.7560 |              0.9318 |
| MSTR/sma50_200_cooldown_10_confirm_2 | observation_only                  | MSTR is high-beta observation only and cannot represent Layer5.                                    | 0.3473 |        -0.7025 |   0.4944 |              0.5973 |
| QQQ/trailing_stop_15pct              | observation_only                  | Risk observation candidate retained to document parameter sensitivity.                             | 0.1618 |        -0.2460 |   0.6580 |              0.5852 |

## 5. 成本压力测试结论

20bps 成本结果如下。高换手的 momentum / volatility filter 候选更容易变成 cost_sensitive，后续不能直接进入组合构建。

| candidate_key                        |   CAGR |   Calmar |   cost_drag_CAGR | pass_cost_stress   |
|:-------------------------------------|-------:|---------:|-----------------:|:-------------------|
| NVDA/sma50_200_cooldown_5_confirm_1  | 0.5936 |   1.5806 |           0.0022 | True               |
| NVDA/ts_mom_63d                      | 0.5708 |   1.1611 |           0.0303 | True               |
| SOXX/sma_20_120                      | 0.2490 |   0.8410 |           0.0056 | True               |
| UPRO/vol_filter_63d                  | 0.1931 |   0.8250 |           0.0175 | True               |
| SPY/vol_filter_63d                   | 0.0652 |   0.7899 |           0.0155 | True               |
| GOOGL/vol_filter_20d                 | 0.1374 |   0.6570 |           0.0300 | True               |
| MSFT/sma_50_200                      | 0.2096 |   0.7476 |           0.0023 | True               |
| MSTR/sma50_200_cooldown_10_confirm_2 | 0.3442 |   0.4890 |           0.0032 | True               |
| QQQ/trailing_stop_15pct              | 0.1557 |   0.5831 |           0.0062 | True               |

## 6. Period slice 结论

latest_12m / latest_24m 是当前最重要的近期退化检查。若这些窗口为负或明显弱于 benchmark，应降级为 conditional。

| candidate_key                        | period_slice   |    CAGR |   Calmar | slice_notes                                                             |
|:-------------------------------------|:---------------|--------:|---------:|:------------------------------------------------------------------------|
| NVDA/sma50_200_cooldown_5_confirm_1  | latest_12m     |  0.2563 |   1.2679 | underperforms_without_mdd_benefit                                       |
| NVDA/sma50_200_cooldown_5_confirm_1  | latest_24m     |  0.3144 |   1.1069 | ok                                                                      |
| NVDA/ts_mom_63d                      | latest_12m     |  0.1689 |   0.5573 | underperforms_without_mdd_benefit                                       |
| NVDA/ts_mom_63d                      | latest_24m     |  0.2395 |   0.7905 | ok                                                                      |
| SOXX/sma_20_120                      | latest_12m     |  1.1942 |   7.5745 | ok                                                                      |
| SOXX/sma_20_120                      | latest_24m     |  0.4145 |   1.4752 | ok                                                                      |
| UPRO/vol_filter_63d                  | latest_12m     |  0.1488 |   0.9710 | underperforms_without_mdd_benefit                                       |
| UPRO/vol_filter_63d                  | latest_24m     |  0.0679 |   0.2984 | underperforms_without_mdd_benefit                                       |
| SPY/vol_filter_63d                   | latest_12m     |  0.0655 |   1.2922 | ok                                                                      |
| SPY/vol_filter_63d                   | latest_24m     |  0.0381 |   0.5079 | ok                                                                      |
| GOOGL/vol_filter_20d                 | latest_12m     |  0.6318 |   4.7647 | ok                                                                      |
| GOOGL/vol_filter_20d                 | latest_24m     |  0.2917 |   2.1996 | ok                                                                      |
| MSFT/sma_50_200                      | latest_12m     | -0.0424 |  -0.2364 | negative_CAGR;underperforms_without_mdd_benefit;weak_recent_performance |
| MSFT/sma_50_200                      | latest_24m     | -0.0335 |  -0.1422 | negative_CAGR;underperforms_without_mdd_benefit;weak_recent_performance |
| MSTR/sma50_200_cooldown_10_confirm_2 | latest_12m     | -0.1360 |  -0.3996 | negative_CAGR;underperforms_without_mdd_benefit;weak_recent_performance |
| MSTR/sma50_200_cooldown_10_confirm_2 | latest_24m     |  0.7599 |   1.5265 | ok                                                                      |
| QQQ/trailing_stop_15pct              | latest_12m     |  0.4247 |   3.5499 | ok                                                                      |
| QQQ/trailing_stop_15pct              | latest_24m     |  0.1998 |   0.8950 | ok                                                                      |

## 7. Rolling validation 结论

| candidate_key                        | rolling_window   |   rolling_window_count |   rolling_pass_rate |   worst_rolling_CAGR |   worst_rolling_MDD | rolling_validation_notes   |
|:-------------------------------------|:-----------------|-----------------------:|--------------------:|---------------------:|--------------------:|:---------------------------|
| NVDA/sma50_200_cooldown_5_confirm_1  | 3Y               |                     88 |              1.0000 |               0.3763 |             -0.3755 | ok                         |
| NVDA/sma50_200_cooldown_5_confirm_1  | 5Y               |                     64 |              1.0000 |               0.3695 |             -0.3755 | ok                         |
| NVDA/ts_mom_63d                      | 3Y               |                     88 |              1.0000 |               0.2082 |             -0.4853 | ok                         |
| NVDA/ts_mom_63d                      | 5Y               |                     64 |              1.0000 |               0.2393 |             -0.4853 | ok                         |
| SOXX/sma_20_120                      | 3Y               |                     88 |              0.5455 |               0.0534 |             -0.2961 | ok                         |
| SOXX/sma_20_120                      | 5Y               |                     64 |              0.7188 |               0.1278 |             -0.2961 | ok                         |
| UPRO/vol_filter_63d                  | 3Y               |                     88 |              0.6818 |               0.0952 |             -0.2277 | ok                         |
| UPRO/vol_filter_63d                  | 5Y               |                     64 |              0.9219 |               0.1602 |             -0.2277 | ok                         |
| SPY/vol_filter_63d                   | 3Y               |                     88 |              1.0000 |               0.0342 |             -0.0786 | ok                         |
| SPY/vol_filter_63d                   | 5Y               |                     64 |              1.0000 |               0.0630 |             -0.0786 | ok                         |
| GOOGL/vol_filter_20d                 | 3Y               |                     88 |              0.7955 |               0.0379 |             -0.1964 | ok                         |
| GOOGL/vol_filter_20d                 | 5Y               |                     64 |              1.0000 |               0.0864 |             -0.1964 | ok                         |
| MSFT/sma_50_200                      | 3Y               |                     88 |              0.8636 |               0.0886 |             -0.2804 | ok                         |
| MSFT/sma_50_200                      | 5Y               |                     64 |              1.0000 |               0.1004 |             -0.2804 | ok                         |
| MSTR/sma50_200_cooldown_10_confirm_2 | 3Y               |                     88 |              0.6477 |              -0.1979 |             -0.7025 | has_negative_rolling_CAGR  |
| MSTR/sma50_200_cooldown_10_confirm_2 | 5Y               |                     64 |              0.5469 |               0.0723 |             -0.7025 | ok                         |
| QQQ/trailing_stop_15pct              | 3Y               |                     88 |              0.5455 |               0.0172 |             -0.2460 | ok                         |
| QQQ/trailing_stop_15pct              | 5Y               |                     64 |              0.6250 |               0.0854 |             -0.2460 | ok                         |

## 8. Top-month sensitivity 结论

出现 top-month dependency 的候选如下。若剔除 best 3/5 months 后 CAGR 或 Calmar 塌陷，不能直接 pass。

| candidate_key                        | removal_case   |   CAGR |   Calmar |   monthly_return_concentration_ratio |
|:-------------------------------------|:---------------|-------:|---------:|-------------------------------------:|
| MSTR/sma50_200_cooldown_10_confirm_2 | best_3_months  | 0.1175 |   0.2305 |                               0.3028 |
| MSTR/sma50_200_cooldown_10_confirm_2 | best_5_months  | 0.0209 |   0.0392 |                               0.3028 |

## 9. 参数邻域复核结论

小邻域复核未做新搜索，只围绕冻结候选的局部参数变化。cliff drop 如下：

| base_candidate                      | neighbor_candidate                   |   CAGR_drop_vs_base |   Calmar_ratio_vs_base |
|:------------------------------------|:-------------------------------------|--------------------:|-----------------------:|
| NVDA/sma50_200_cooldown_5_confirm_1 | NVDA/sma60_220_cooldown_0_confirm_2  |              0.1542 |                 0.5355 |
| NVDA/sma50_200_cooldown_5_confirm_1 | NVDA/sma60_220_cooldown_5_confirm_2  |              0.1542 |                 0.5355 |
| NVDA/sma50_200_cooldown_5_confirm_1 | NVDA/sma60_220_cooldown_10_confirm_2 |              0.1542 |                 0.5355 |
| UPRO/vol_filter_63d                 | UPRO/vol_filter_20d_threshold_126    |              0.1492 |                 0.1690 |
| UPRO/vol_filter_63d                 | UPRO/vol_filter_20d_threshold_252    |              0.0849 |                 0.3856 |
| UPRO/vol_filter_63d                 | UPRO/vol_filter_42d_threshold_126    |              0.0874 |                 0.2723 |
| UPRO/vol_filter_63d                 | UPRO/vol_filter_84d_threshold_126    |              0.0983 |                 0.2591 |
| UPRO/vol_filter_63d                 | UPRO/vol_filter_84d_threshold_252    |              0.0599 |                 0.3961 |
| SPY/vol_filter_63d                  | SPY/vol_filter_20d_threshold_126     |              0.0383 |                 0.3063 |
| SPY/vol_filter_63d                  | SPY/vol_filter_20d_threshold_252     |              0.0271 |                 0.4418 |
| SPY/vol_filter_63d                  | SPY/vol_filter_42d_threshold_126     |              0.0169 |                 0.3456 |
| SPY/vol_filter_63d                  | SPY/vol_filter_84d_threshold_126     |              0.0346 |                 0.2492 |
| SPY/vol_filter_63d                  | SPY/vol_filter_84d_threshold_252     |              0.0175 |                 0.2983 |
| GOOGL/vol_filter_20d                | GOOGL/vol_filter_42d_threshold_126   |              0.0668 |                 0.3907 |
| GOOGL/vol_filter_20d                | GOOGL/vol_filter_84d_threshold_252   |              0.0369 |                 0.4527 |
| QQQ/trailing_stop_15pct             | QQQ/trailing_stop_20pct              |              0.0344 |                 0.4885 |

## 10. Benchmark 对比结论

特别是 NVDA 候选，buy-and-hold CAGR 更高，但择时策略显著降低 MDD，因此不能只看 CAGR。

| candidate_key                        |   strategy_CAGR |   benchmark_CAGR |   strategy_MDD |   benchmark_MDD |   excess_CAGR |   MDD_reduction | benchmark_pass_flag   |
|:-------------------------------------|----------------:|-----------------:|---------------:|----------------:|--------------:|----------------:|:----------------------|
| NVDA/sma50_200_cooldown_5_confirm_1  |          0.5958 |           0.7097 |        -0.3755 |         -0.6634 |       -0.1139 |          0.2878 | True                  |
| NVDA/ts_mom_63d                      |          0.6011 |           0.7097 |        -0.4853 |         -0.6634 |       -0.1085 |          0.1781 | True                  |
| SOXX/sma_20_120                      |          0.2546 |           0.3197 |        -0.2961 |         -0.4575 |       -0.0651 |          0.1614 | True                  |
| UPRO/vol_filter_63d                  |          0.2106 |           0.2895 |        -0.2277 |         -0.7682 |       -0.0788 |          0.5405 | True                  |
| SPY/vol_filter_63d                   |          0.0806 |           0.1505 |        -0.0786 |         -0.3372 |       -0.0699 |          0.2586 | True                  |
| GOOGL/vol_filter_20d                 |          0.1674 |           0.2533 |        -0.1964 |         -0.4432 |       -0.0858 |          0.2468 | True                  |
| MSFT/sma_50_200                      |          0.2120 |           0.2330 |        -0.2804 |         -0.3715 |       -0.0210 |          0.0911 | False                 |
| MSTR/sma50_200_cooldown_10_confirm_2 |          0.3473 |           0.2546 |        -0.7025 |         -0.8927 |        0.0928 |          0.1901 | True                  |
| QQQ/trailing_stop_15pct              |          0.1618 |           0.2014 |        -0.2460 |         -0.3512 |       -0.0396 |          0.1052 | True                  |

## 11. NVDA 候选是否只是 AI bull / 单票集中

NVDA 两个候选仍然是单 ticker，存在 AI bull 与单票集中风险。SMA/cooldown 版本的核心价值在于降低回撤，而不是超越 NVDA buy-and-hold 的 CAGR。下一步若继续，必须做 portfolio construction，不能把单票候选直接当最终策略。

## 12. SOXX 候选是否可代表 Layer3

SOXX `sma_20_120` 可以作为 Layer3 Sector/theme ETF 的一个可验证候选，但不能代表整个 Layer3。下一步应与 SMH/SOXX/XLK 等同层候选做组合级验证。

## 13. UPRO 候选是否只能作为 leveraged ETF 单独策略

是。UPRO `vol_filter_63d` 即使进入下一步，也只能作为 leveraged ETF separate bucket，不能和普通 equity/ETF 混排。

## 14. MSTR 为什么只能 observation

MSTR 属于 High-beta observation bucket。Layer5 大部分 ticker 因上市历史不足 10 年仍被排除，所以 MSTR 不代表完整 Layer5，且自身回撤/波动特征极端。

## 15. 下一步建议

建议进入有限的 `portfolio construction test` 和 `K 线买卖点可视化`，对象仅限本轮 pass/conditional 的少量候选。仍不建议 formal MVE2，不建议扩 universe，也不建议继续大范围搜索。

## 16. Formal MVE2 结论

本轮仍不支持 formal MVE2。当前只支持 limited MVE2 后续验证链条。
